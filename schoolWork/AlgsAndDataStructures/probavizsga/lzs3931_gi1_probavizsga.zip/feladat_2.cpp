/*
 * Hallgató neve: Lukács Zsolt
 * Csoport: GI 1. csoport
 * Azonosító: 3931
 * */

#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*
 * 0 1 1 2 3 5 8 ...
 * 8 + 5 = 13, 8 + 3 = 11, 8 + 2 = 10;
 * 5 + 3 = 8; 5 + 3 + 2 = 10;
 * 3 + 2 = 5; 3 + 2 + 1 = 6; 3 + 2 + 1 + 1 = 7;
 * */

/*
 * 1 + 1 + 2 + 3 + 5 = 12
 * 1 + 2 + 3 + 5 = 11
 * 2 + 3 + 5 = 10
 * */

void keres_osszeg(const int &n);

int main() {
    int n;
    do {
        cin >> n;
    } while (n < 0);

    keres_osszeg(n);

    return 0;
}

void keres_osszeg(const int &n) {
    vector<int> fib_szamok;
    string eredmeny;

    // legeneráljuk a fibonacci számokat, addig amíg kisebbek, mint a szám amit vizsgálunk
    int elso_fib = 0;
    int masodik_fib = 1;
    int harmadik_fib;
    do {
        fib_szamok.push_back(masodik_fib);

        harmadik_fib = elso_fib + masodik_fib;
        elso_fib = masodik_fib;
        masodik_fib = harmadik_fib;
    } while (harmadik_fib < n);

    // kezdve a fib számokat tartalmazó tömb elejétől,
    // keresünk olyan összegeket, amelyek megfelelnek a feltételnek
    // felhasználjuk azt a tulajdonságát a fib sorozatnak, hogy
    // növekvő sorrendbe követik egymást az értékek,
    // tehát, haladunk a kisebb számtól, összeadjuk a nagyobbakkal, ha kapunk
    // egy olyan összeget, amely megfelel a bemeneti számnak, végeredményt kaptunk,
    // ha az összeg a bemeneti számnál nagyobb, akkor eggyel nagyobb számtól kezdve próbáljuk az összeget
    // megtalálni
    // addig folytatjuk ezt, amíg végeredményhez nem jutunk, vagy nem marad elegendő fib számunk, hogy
    // kéttagú összeget alkossanak
    int i = 0;
    while (i < fib_szamok.size() - 1) {
        int osszeg = fib_szamok[i];
        eredmeny += to_string(fib_szamok[i]);

        for (int j = i + 1; j < fib_szamok.size(); ++j) {
            osszeg += fib_szamok[j];
            eredmeny += " + ";
            eredmeny += to_string(fib_szamok[j]);

            if (osszeg == n) {
                break;
            } else if (osszeg > n) {
                eredmeny = "";
                break;
            }
        }

        if (!eredmeny.empty()) {
            break;
        } else {
            ++i;
        }
    }

    cout << eredmeny << '\n';
}